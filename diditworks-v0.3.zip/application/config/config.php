<?php

/**
 * ----------------------------------------------------------------
 * CONFIG FILE
 * ----------------------------------------------------------------
 * 
 * this file contains config values held in an array called $config
 * each key in the array holds a config item
 * 
 * @package diditworks
 * @author Paul Mulgrew <paul@diditmedia.com> 
 */

/*
 * ----------------------------------------------------------------
 * CORE CLASSES
 * ----------------------------------------------------------------
 * 
 * Set which core classes should be loaded automatically
 * 
 */

$config['core_classes'] = array('config','model');

/*
 * ---------------------------------------------------------------
 * DEFAULT APPLICATION DIRECTORIES
 * ---------------------------------------------------------------
 * 
 * This will allow you to change the location of the application
 * directories for controllers, models and views
 * 
 */

$config['controllers']  = 'controllers';
$config['models']       = 'models';
$config['views']        = 'views';

/*
 * ---------------------------------------------------------------
 * DEFAULT ROUTE
 * ---------------------------------------------------------------
 * 
 * when the router doesnt find a controller it will run this one.
 * 
 */

$config['default_route'] = 'home';

/*
 * ---------------------------------------------------------------
 * DATABASE SETTINGS
 * ---------------------------------------------------------------
 * 
 */

$config['dbhost']       = 'localhost';
$config['dbname']       = 'diditmed_fw';
$config['dbuser']       = 'root';
$config['dbpass']       = '';

$config['dsn']          = 'mysql: host='.$config['dbhost'].';dbname='.$config['dbname'].';';

?>
