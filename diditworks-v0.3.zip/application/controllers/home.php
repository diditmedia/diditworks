<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of home
 *
 * @author Paul Mulgrew
 */
class home extends controller
{

        function __construct()
        {
                parent::__construct();
                $this->db =& load('db');
                $this->post_model = $this->loader->model('post_model');

        }
        
        function index()
        {
                
                $data['posts'] = $this->post_model->get_posts();
                $this->loader->view('template/header');
                $view = $this->loader->view('home/hello', $data);
                $this->loader->view('template/footer');
                $view->build_output();
                
               

                
        }

}

?>
