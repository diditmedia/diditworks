<?php foreach($posts as $post) :?>
<h2><?= $post['post_title'] ?></h2>
<p><?= $post['post_content'] ?></p>
<?php endforeach; ?>

